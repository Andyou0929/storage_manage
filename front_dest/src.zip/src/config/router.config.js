// eslint-disable-next-line
import { UserLayout, BasicLayout, BlankLayout } from '@/layouts'
import { bxAnaalyse } from '@/core/icons'

const RouteView = {
    name: 'RouteView',
    render: h => h('router-view')
}

export const asyncRouterMap = [{
        path: '/',
        name: 'index',
        component: BasicLayout,
        meta: { title: 'menu.home' },
        redirect: '/home',
        children: [
            // dashboard
          {
            path: '/home',
            name: '主页',
            hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
            component: () =>
              import ('@/views/home/index'),
            hidden:true,
            meta: { title: '主页', icon: 'user', keepAlive: true, permission: ['table'] }
          },
            {
                path: '/user/list/',
                name: '用户管理',
                hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
                component: () =>
                    import ('@/views/user/list'),
                meta: { title: '用户管理', icon: 'user', keepAlive: true, permission: ['table'] }
            },
          {
            path: '/storage/list/',
            name: '仓库管理',
            hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
            component: () =>
              import ('@/views/storage/list'),
            meta: { title: '仓库管理', icon: 'bank', keepAlive: true, permission: ['table'] }
          },
          {
            path: '/provider/list/',
            name: '供应商管理',
            hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
            component: () =>
              import ('@/views/provider/list'),
            meta: { title: '供应商管理', icon: 'money-collect', keepAlive: true, permission: ['table'] }
          },
          {
            path: '/customer/list/',
            name: '客户管理',
            hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
            component: () =>
              import ('@/views/customer/list'),
            meta: { title: '客户管理', icon: 'shop', keepAlive: true, permission: ['table'] }
          },
          {
            path: '/goods/list/',
            name: '货物管理',
            hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
            component: () =>
              import ('@/views/goods/list'),
            meta: { title: '货物管理', icon: 'codepen', keepAlive: true, permission: ['table'] }
          },
          {
            path: '/inStorage/list/',
            name: '入库订单管理',
            hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
            component: () =>
              import ('@/views/inStorage/list'),
            meta: { title: '入库订单管理', icon: 'import', keepAlive: true, permission: ['table'] }
          },
          {
            path: '/outStorage/list/',
            name: '出库订单管理',
            hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
            component: () =>
              import ('@/views/outStorage/list'),
            meta: { title: '出库订单管理', icon: 'export', keepAlive: true, permission: ['table'] }
          },
          {
            path: '/logoData/list/',
            name: '操作日志',
            hideChildrenInMenu: true, // 强制显示 MenuItem 而不是 SubMenu
            component: () =>
              import ('@/views/logoData/list'),
            meta: { title: '操作日志', icon: 'file-done', keepAlive: true, permission: ['table'] }
          },

            // other
            /*
            {
              path: '/other',
              name: 'otherPage',
              component: PageView,
              meta: { title: '其他组件', icon: 'slack', permission: [ 'dashboard' ] },
              redirect: '/other/icon-selector',
              children: [
                {
                  path: '/other/icon-selector',
                  name: 'TestIconSelect',
                  component: () => import('@/views/other/IconSelectorView'),
                  meta: { title: 'IconSelector', icon: 'tool', keepAlive: true, permission: [ 'dashboard' ] }
                },
                {
                  path: '/other/list',
                  component: RouteView,
                  meta: { title: '业务布局', icon: 'layout', permission: [ 'support' ] },
                  redirect: '/other/list/tree-list',
                  children: [
                    {
                      path: '/other/list/tree-list',
                      name: 'TreeList',
                      component: () => import('@/views/other/TreeList'),
                      meta: { title: '树目录表格', keepAlive: true }
                    },
                    {
                      path: '/other/list/edit-table',
                      name: 'EditList',
                      component: () => import('@/views/other/TableInnerEditList'),
                      meta: { title: '内联编辑表格', keepAlive: true }
                    },
                    {
                      path: '/other/list/user-list',
                      name: 'UserList',
                      component: () => import('@/views/other/UserList'),
                      meta: { title: '用户列表', keepAlive: true }
                    },
                    {
                      path: '/other/list/role-list',
                      name: 'RoleList',
                      component: () => import('@/views/other/RoleList'),
                      meta: { title: '角色列表', keepAlive: true }
                    },
                    {
                      path: '/other/list/system-role',
                      name: 'SystemRole',
                      component: () => import('@/views/role/RoleList'),
                      meta: { title: '角色列表2', keepAlive: true }
                    },
                    {
                      path: '/other/list/permission-list',
                      name: 'PermissionList',
                      component: () => import('@/views/other/PermissionList'),
                      meta: { title: '权限列表', keepAlive: true }
                    }
                  ]
                }
              ]
            }
            */
        ]
    },
    {
        path: '*',
        redirect: '/404',
        hidden: true
    }
]

/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [{
        path: '/user',
        component: UserLayout,
        redirect: '/user/login',
        hidden: true,
        children: [{
                path: 'login',
                name: 'login',
                component: () =>
                    import ( /* webpackChunkName: "user" */ '@/views/user/Login')
            },
            {
                path: 'register',
                name: 'register',
                component: () =>
                    import ( /* webpackChunkName: "user" */ '@/views/user/Register')
            },
            {
                path: 'register-result',
                name: 'registerResult',
                component: () =>
                    import ( /* webpackChunkName: "user" */ '@/views/user/RegisterResult')
            },
            {
                path: 'recover',
                name: 'recover',
                component: undefined
            }
        ]
    },

    {
        path: '/404',
        component: () =>
            import ( /* webpackChunkName: "fail" */ '@/views/exception/404')
    }
]