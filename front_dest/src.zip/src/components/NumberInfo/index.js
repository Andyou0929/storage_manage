import NumberInfo from './NumberInfo'

export default NumberInfo
